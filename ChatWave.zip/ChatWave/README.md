# 💬 ChatWave — Multi-User Local Chat

> OOP2 Final Project · **Group 2** · Python 3 · PyQt6 · TCP sockets

ChatWave is a desktop chat application for a local network. One computer runs the
**server**; any number of **clients** log in, pick an avatar and chat in a shared
group room or privately with each other.

| Login | Group chat |
|---|---|
| ![Login](docs/screenshots/login.png) | ![Group chat](docs/screenshots/chat_group.png) |

## ✨ Features

| # | Feature | Details |
|---|---------|---------|
| 1 | **Login** | Username, *optional* password (stored as a salted PBKDF2 hash), 10 avatars, "Remember me" |
| 2 | **Multi-user chat** | Many accounts connected at once through the local server |
| 3 | **Chat thread** | Avatar, username, message and date/time, e.g. `😎 Hail [September 12, 2026 • 08:45 AM]: Hello!` |
| 4 | **Emoji picker** | 😊 button opens a tabbed picker (faces, gestures, hearts, objects, animals) |
| 5 | **Send button** | Sends the message to everyone connected |
| 6 | **Enter to send** | Pressing Enter does the same |
| 7 | **Edit message** | *Edit last message* loads your last message back into the input; Enter saves and **everyone sees it updated** |
| 8 | **Chat list** | Group chat + every user, online dots, last-message preview, unread badges, search |
| 9 | **Private chats** | Click a user to chat one-to-one (offline users receive messages at next login) |
| 10 | **Server** | Threaded TCP server, join/leave notices, saved accounts and history |

## 🧱 Architecture

```mermaid
flowchart LR
    subgraph Client["client/ (PyQt6)"]
        L[LoginWindow] --> N[NetworkClient]
        C[ChatWindow] --> N
        E[EmojiPicker] --> C
        W[ChatTile / AvatarWidget] --> C
    end
    subgraph Server["server/"]
        S[ChatServer<br/>1 thread per client] --> D[(Storage<br/>accounts.json<br/>history.json)]
    end
    N <-->|"JSON lines over TCP"| S
    P[common/protocol.py] -.shared by.- N
    P -.shared by.- S
```

**Message flow:** `Send` → `NetworkClient.send()` → server validates & stores →
server pushes the packet to every recipient → each client's reader thread emits a
Qt signal → `ChatWindow` updates the thread. The sender sees their own message
only after the server echoes it, so everybody's view always matches the server.

### Project structure

```
ChatWave/
├── common/protocol.py     # packet types, constants, PacketReader (shared)
├── server/
│   ├── __main__.py        # python -m server
│   ├── chat_server.py     # sockets, sessions, routing
│   └── storage.py         # accounts + history (JSON), password hashing
├── client/
│   ├── __main__.py        # python -m client
│   ├── login_window.py    # login dialog
│   ├── chat_window.py     # chat list + thread + input
│   ├── emoji_picker.py    # emoji pop-up
│   ├── widgets.py         # AvatarWidget, ChatTile
│   ├── network.py         # handshake + reader thread
│   ├── styles.py          # purple theme
│   └── config.py
├── tests/test_server.py   # 11 integration tests
└── docs/screenshots/
```

## 🚀 Getting started

```bash
git clone https://github.com/<your-username>/ChatWave.git
cd ChatWave
python -m venv .venv
.venv\Scripts\activate          # Windows   (macOS/Linux: source .venv/bin/activate)
pip install -r requirements.txt
```

**1. Start the server** (one computer):
```bash
python -m server                 # options: --port 5555 --host 0.0.0.0
```

**2. Start clients** (as many as you like, each in its own terminal):
```bash
python -m client
```

**Chatting across computers on the same Wi-Fi/LAN:** on the server PC find its IP
(`ipconfig` on Windows), allow Python/port 5555 through the firewall, then each
classmate types `that-ip:5555` into the **Server** field on the login screen.

## 🧪 Tests

```bash
python -m unittest discover -s tests -t . -v
```
Covers login rules, passwords, duplicate logins, broadcast, private-message
privacy, edit permissions, TCP packet framing and history delivery.

## 📡 Protocol (summary)

One JSON object per line. Full list in `common/protocol.py`.

| Direction | Packet | Purpose |
|-----------|--------|---------|
| C → S | `login`, `message`, `edit` | authenticate, send text (`to` = null for group), edit own message |
| S → C | `login_ok`, `login_error` | handshake result (+ user list and history) |
| S → C | `message`, `edited`, `users`, `system`, `error` | live updates |

## 🔒 Security notes

* Passwords are salted + hashed (PBKDF2-SHA256), never stored in plain text and never remembered by the client.
* The server validates usernames, message length and edit ownership.
* Traffic is **not encrypted** (plain TCP) — intended for a trusted local network.

## 🗺️ Future improvements

TLS encryption · delete messages · image/file sharing · typing indicators ·
read receipts · multiple group rooms.

## 👥 Team

| Name | Role |
|------|------|
| _Member 1_ | _e.g. Server & protocol_ |
| _Member 2_ | _e.g. Login & chat UI_ |
| _Member 3_ | _e.g. Emoji picker & testing_ |

Licensed under the [MIT License](LICENSE).
