"""Reusable widgets: round avatar with online dot, and a chat-list tile."""
from __future__ import annotations

from PyQt6.QtCore import QRectF, Qt, pyqtSignal
from PyQt6.QtGui import QBrush, QColor, QFont, QPainter
from PyQt6.QtWidgets import QFrame, QHBoxLayout, QLabel, QVBoxLayout, QWidget

from client.styles import ACCENT, MUTED, ONLINE, PRIMARY, SURFACE, TEXT

AVATAR_COLORS = ["#6C63FF", "#FF9F0A", "#0A84FF", "#BF5AF2", "#30D158", "#FF375F", "#64D2FF", "#5E5CE6"]


def color_for(name: str) -> str:
    """Stable colour per name so a user always gets the same avatar background."""
    return AVATAR_COLORS[sum(ord(c) for c in name) % len(AVATAR_COLORS)]


class AvatarWidget(QWidget):
    """Coloured circle containing an emoji; optional green online badge."""

    def __init__(self, symbol: str, color: str, online: bool | None = None, size: int = 46) -> None:
        super().__init__()
        self._size = size
        self.symbol, self.color, self.online = symbol, color, online
        self.setFixedSize(size, size)

    def set_state(self, symbol: str | None = None, online: bool | None = None) -> None:
        if symbol is not None:
            self.symbol = symbol
        self.online = online
        self.update()

    def paintEvent(self, _event) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        d = self._size - 6
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(QColor(self.color)))
        p.drawEllipse(2, 2, d, d)
        p.setPen(QColor("white"))
        font = QFont()
        font.setPointSize(max(10, d // 2 - 2))
        p.setFont(font)
        p.drawText(QRectF(2, 2, d, d), Qt.AlignmentFlag.AlignCenter, self.symbol)
        if self.online is not None:
            r = self._size // 3
            x = self._size - r - 1
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QBrush(QColor(SURFACE)))
            p.drawEllipse(x - 2, x - 2, r + 4, r + 4)
            p.setBrush(QBrush(QColor(ONLINE if self.online else "#C4C1DA")))
            p.drawEllipse(x, x, r, r)


class ChatTile(QFrame):
    """One row of the conversation list: avatar, name, last message, time, unread badge."""

    clicked = pyqtSignal(str)

    def __init__(self, key: str, title: str, symbol: str, online: bool | None) -> None:
        super().__init__()
        self.key, self.title = key, title
        self.setObjectName("ChatTile")
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self._apply_style(False)

        self.avatar = AvatarWidget(symbol, color_for(title), online)
        self.name_label = QLabel(title)
        self.name_label.setStyleSheet(f"font-weight: 700; font-size: 14px; color: {TEXT};")
        self.time_label = QLabel("")
        self.time_label.setStyleSheet(f"font-size: 11px; color: {MUTED};")
        self.preview_label = QLabel("No messages yet")
        for label in (self.name_label, self.preview_label):
            label.setTextFormat(Qt.TextFormat.PlainText)   # never interpret user text as HTML
        self.preview_label.setStyleSheet(f"font-size: 12px; color: {MUTED};")
        self.badge = QLabel("0")
        self.badge.setFixedSize(20, 20)
        self.badge.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.badge.setStyleSheet(
            f"background: {ACCENT}; color: white; font-weight: bold; font-size: 10px; border-radius: 10px;")
        self.badge.hide()

        top = QHBoxLayout()
        top.addWidget(self.name_label)
        top.addStretch()
        top.addWidget(self.time_label)
        bottom = QHBoxLayout()
        bottom.addWidget(self.preview_label, 1)
        bottom.addWidget(self.badge)
        info = QVBoxLayout()
        info.setSpacing(3)
        info.addLayout(top)
        info.addLayout(bottom)
        row = QHBoxLayout(self)
        row.setContentsMargins(10, 8, 12, 8)
        row.setSpacing(10)
        row.addWidget(self.avatar)
        row.addLayout(info, 1)

    def _apply_style(self, selected: bool) -> None:
        bg, border = ("#E8E5FF", PRIMARY) if selected else (SURFACE, "#E6E3FF")
        self.setStyleSheet(f"""
            QFrame#ChatTile {{ background: {bg}; border: 1px solid {border}; border-radius: 14px; }}
            QFrame#ChatTile:hover {{ background: #F1EEFF; }}
            QLabel {{ background: transparent; }}
        """)

    def set_selected(self, selected: bool) -> None:
        self._apply_style(selected)

    def set_preview(self, text: str, when: str) -> None:
        self.preview_label.setText(text if len(text) <= 30 else text[:29] + "…")
        self.time_label.setText(when)

    def set_unread(self, count: int) -> None:
        self.badge.setText(str(min(count, 99)))
        self.badge.setVisible(count > 0)

    def mousePressEvent(self, event) -> None:
        if event.button() == Qt.MouseButton.LeftButton:
            self.clicked.emit(self.key)
