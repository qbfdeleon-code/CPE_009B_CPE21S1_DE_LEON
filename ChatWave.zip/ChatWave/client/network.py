"""Client networking: blocking login handshake + background reader thread.

The reader thread never touches widgets. It emits Qt signals, and Qt delivers
them to the GUI thread (queued connection), which keeps the UI thread-safe.
"""
from __future__ import annotations

import socket
import threading

from PyQt6.QtCore import QObject, pyqtSignal

from client.config import CONNECT_TIMEOUT, HANDSHAKE_TIMEOUT
from common.protocol import (
    LOGIN, LOGIN_ERROR, LOGIN_OK, PacketReader, ProtocolError, encode_packet,
)


class NetworkError(Exception):
    """User-presentable connection or login failure."""


class NetworkClient(QObject):
    packet_received = pyqtSignal(dict)
    connection_lost = pyqtSignal()

    def __init__(self) -> None:
        super().__init__()
        self._sock: socket.socket | None = None
        self._reader = PacketReader()
        self._pending: list[dict] = []
        self._send_lock = threading.Lock()
        self._closing = False

    # -------------------------------------------------------------- handshake
    def login(self, host: str, port: int, username: str, password: str, avatar: str) -> dict:
        """Connect and log in. Returns the server's ``login_ok`` packet or raises NetworkError."""
        self.close()
        self._closing = False
        self._reader = PacketReader()
        self._pending = []
        try:
            sock = socket.create_connection((host, port), timeout=CONNECT_TIMEOUT)
        except OSError as exc:
            raise NetworkError(
                f"Could not connect to {host}:{port}.\nMake sure the server is running."
            ) from exc
        try:
            sock.settimeout(HANDSHAKE_TIMEOUT)
            sock.sendall(encode_packet({"type": LOGIN, "username": username,
                                        "password": password, "avatar": avatar}))
            reply = self._read_first_packet(sock)
        except (OSError, ProtocolError) as exc:
            sock.close()
            raise NetworkError("The server did not answer the login request.") from exc

        if reply is None or reply["type"] == LOGIN_ERROR or reply["type"] != LOGIN_OK:
            sock.close()
            reason = reply.get("reason") if reply else None
            raise NetworkError(reason or "Login failed.")
        sock.settimeout(None)
        self._sock = sock
        return reply

    def _read_first_packet(self, sock: socket.socket) -> dict | None:
        while not self._pending:
            data = sock.recv(4096)
            if not data:
                return None
            self._pending.extend(self._reader.feed(data))
        return self._pending.pop(0)   # anything else stays queued for the reader thread

    # ---------------------------------------------------------------- runtime
    def start_listening(self) -> None:
        threading.Thread(target=self._listen, daemon=True).start()

    def _listen(self) -> None:
        sock = self._sock
        try:
            for packet in self._pending:
                self.packet_received.emit(packet)
            self._pending = []
            while sock is not None:
                data = sock.recv(4096)
                if not data:
                    break
                for packet in self._reader.feed(data):
                    self.packet_received.emit(packet)
        except (OSError, ProtocolError):
            pass
        if not self._closing:
            self.connection_lost.emit()

    def send(self, packet: dict) -> bool:
        if self._sock is None:
            return False
        try:
            with self._send_lock:
                self._sock.sendall(encode_packet(packet))
            return True
        except OSError:
            return False

    def close(self) -> None:
        self._closing = True
        if self._sock is not None:
            try:
                self._sock.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            self._sock.close()
            self._sock = None
