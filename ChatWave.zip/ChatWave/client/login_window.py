"""Login dialog: username, optional password, avatar picker, server address."""
from __future__ import annotations

from PyQt6.QtCore import QRectF, QSettings, Qt
from PyQt6.QtGui import QBrush, QColor, QLinearGradient, QPainter
from PyQt6.QtWidgets import (
    QApplication, QButtonGroup, QCheckBox, QDialog, QFrame, QGridLayout, QHBoxLayout, QLabel,
    QLineEdit, QPushButton, QToolButton, QVBoxLayout,
)

from client.config import APP_NAME, ORG_NAME
from client.network import NetworkClient, NetworkError
from client.styles import BORDER, DANGER, MUTED, PRIMARY, PRIMARY_SOFT, TEXT
from common.protocol import AVATARS, DEFAULT_HOST, DEFAULT_PORT, USERNAME_PATTERN, USERNAME_RULES


class LoginWindow(QDialog):
    def __init__(self, network: NetworkClient) -> None:
        super().__init__()
        self.network = network
        self.session: dict | None = None      # login_ok packet after a successful login
        self.settings = QSettings(ORG_NAME, APP_NAME)
        self.setWindowTitle(f"{APP_NAME} - Login")
        self.setFixedSize(420, 720)
        self._build_ui()
        self._load_saved()

    # ------------------------------------------------------------------- UI
    def _build_ui(self) -> None:
        outer = QVBoxLayout(self)
        outer.setContentsMargins(30, 36, 30, 26)

        logo = QLabel("💬")
        logo.setFixedSize(64, 64)
        logo.setAlignment(Qt.AlignmentFlag.AlignCenter)
        logo.setStyleSheet(
            "font-size: 28px; border-radius: 32px; color: white;"
            "background: qlineargradient(x1:0,y1:0,x2:1,y2:1, stop:0 #6C63FF, stop:1 #8B6DF6);")
        title = QLabel(APP_NAME)
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setStyleSheet(f"font-size: 28px; font-weight: 800; color: {TEXT}; background: transparent;")
        tagline = QLabel("Connect • Share • Be You")
        tagline.setAlignment(Qt.AlignmentFlag.AlignCenter)
        tagline.setStyleSheet(f"font-size: 12px; color: {MUTED}; background: transparent;")
        outer.addWidget(logo, alignment=Qt.AlignmentFlag.AlignCenter)
        outer.addWidget(title)
        outer.addWidget(tagline)
        outer.addSpacing(14)

        card = QFrame()
        card.setObjectName("LoginCard")
        card.setStyleSheet(f"QFrame#LoginCard {{ background: white; border: 1px solid {BORDER}; border-radius: 18px; }}"
                           "QLabel { background: transparent; }")
        lay = QVBoxLayout(card)
        lay.setContentsMargins(22, 20, 22, 18)
        lay.setSpacing(8)

        welcome = QLabel("Welcome!")
        welcome.setStyleSheet(f"font-size: 18px; font-weight: 700; color: {TEXT};")
        hint = QLabel("Log in to join the chat")
        hint.setStyleSheet(f"font-size: 12px; color: {MUTED};")
        lay.addWidget(welcome)
        lay.addWidget(hint)
        lay.addSpacing(4)

        self.username_input = QLineEdit()
        self.username_input.setPlaceholderText("👤  Username")
        self.username_input.setMaxLength(20)
        lay.addWidget(self.username_input)

        pw_row = QHBoxLayout()
        self.password_input = QLineEdit()
        self.password_input.setPlaceholderText("🔒  Password (optional)")
        self.password_input.setEchoMode(QLineEdit.EchoMode.Password)
        self.show_pw = QToolButton()
        self.show_pw.setText("👁")
        self.show_pw.setCheckable(True)
        self.show_pw.setFixedSize(40, 40)
        self.show_pw.setStyleSheet(f"QToolButton {{ border: 1px solid {BORDER}; border-radius: 10px; background: white; }}"
                                   f"QToolButton:checked {{ background: {PRIMARY_SOFT}; }}")
        self.show_pw.toggled.connect(lambda on: self.password_input.setEchoMode(
            QLineEdit.EchoMode.Normal if on else QLineEdit.EchoMode.Password))
        pw_row.addWidget(self.password_input)
        pw_row.addWidget(self.show_pw)
        lay.addLayout(pw_row)

        lay.addSpacing(4)
        lay.addWidget(self._small_label("Choose avatar"))
        grid = QGridLayout()
        grid.setSpacing(6)
        self.avatar_group = QButtonGroup(self)
        self.avatar_buttons: dict[str, QToolButton] = {}
        for i, emoji in enumerate(AVATARS):
            btn = QToolButton()
            btn.setText(emoji)
            btn.setCheckable(True)
            btn.setFixedSize(46, 46)
            btn.setCursor(Qt.CursorShape.PointingHandCursor)
            btn.setStyleSheet(f"""
                QToolButton {{ font-size: 22px; border: 2px solid transparent; border-radius: 23px; background: #F5F3FF; }}
                QToolButton:hover {{ background: {PRIMARY_SOFT}; }}
                QToolButton:checked {{ border: 2px solid {PRIMARY}; background: {PRIMARY_SOFT}; }}""")
            self.avatar_group.addButton(btn)
            self.avatar_buttons[emoji] = btn
            grid.addWidget(btn, i // 5, i % 5)
        self.avatar_buttons[AVATARS[0]].setChecked(True)
        lay.addLayout(grid)

        lay.addSpacing(4)
        lay.addWidget(self._small_label("Server (host:port)"))
        self.server_input = QLineEdit(f"{DEFAULT_HOST}:{DEFAULT_PORT}")
        lay.addWidget(self.server_input)

        self.remember = QCheckBox("Remember me")
        self.remember.setStyleSheet(f"color: {MUTED}; font-size: 12px;")
        lay.addWidget(self.remember)

        self.error_label = QLabel("")
        self.error_label.setWordWrap(True)
        self.error_label.setMinimumHeight(34)
        self.error_label.setStyleSheet(f"color: {DANGER}; font-size: 12px;")
        lay.addWidget(self.error_label)

        self.join_button = QPushButton("Join Chat  →")
        self.join_button.setObjectName("Primary")
        self.join_button.setDefault(True)
        self.join_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.join_button.clicked.connect(self._attempt_login)
        lay.addWidget(self.join_button)
        outer.addWidget(card)
        outer.addStretch()

    @staticmethod
    def _small_label(text: str) -> QLabel:
        label = QLabel(text)
        label.setStyleSheet(f"font-size: 12px; font-weight: 600; color: {MUTED};")
        return label

    def paintEvent(self, _event) -> None:
        """Soft gradient background with decorative orbs (from the original login mock-up)."""
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        bg = QLinearGradient(0, 0, self.width(), self.height())
        bg.setColorAt(0, QColor("#EEF1FF"))
        bg.setColorAt(1, QColor("#F5F0FF"))
        p.fillRect(self.rect(), bg)
        p.setPen(Qt.PenStyle.NoPen)
        for color, rect in (("#4D8DF7", QRectF(-100, -100, 280, 230)),
                            ("#8B6DF6", QRectF(300, 590, 200, 210)),
                            ("#61B8FF", QRectF(-120, 600, 270, 220))):
            p.setBrush(QBrush(QColor(color)))
            p.setOpacity(0.55)
            p.drawEllipse(rect)

    # ---------------------------------------------------------------- logic
    def _selected_avatar(self) -> str:
        for emoji, btn in self.avatar_buttons.items():
            if btn.isChecked():
                return emoji
        return AVATARS[0]

    def _load_saved(self) -> None:
        if self.settings.value("remember", False, type=bool):
            self.remember.setChecked(True)
            self.username_input.setText(self.settings.value("username", "", type=str))
            self.server_input.setText(self.settings.value("server", self.server_input.text(), type=str))
            saved = self.settings.value("avatar", AVATARS[0], type=str)
            if saved in self.avatar_buttons:
                self.avatar_buttons[saved].setChecked(True)
            self.password_input.setFocus()
        else:
            self.username_input.setFocus()

    def _parse_server(self) -> tuple[str, int] | None:
        text = self.server_input.text().strip() or f"{DEFAULT_HOST}:{DEFAULT_PORT}"
        host, _, port = text.partition(":")
        try:
            return host.strip() or DEFAULT_HOST, int(port) if port else DEFAULT_PORT
        except ValueError:
            return None

    def _show_error(self, text: str) -> None:
        self.error_label.setText(text)

    def _attempt_login(self) -> None:
        username = self.username_input.text().strip()
        if not USERNAME_PATTERN.match(username):
            self._show_error(USERNAME_RULES)
            return
        server = self._parse_server()
        if server is None:
            self._show_error("Server must look like 192.168.1.10:5555")
            return

        self._show_error("")
        self.join_button.setEnabled(False)
        self.join_button.setText("Connecting…")
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        QApplication.processEvents()
        try:
            self.session = self.network.login(server[0], server[1], username,
                                              self.password_input.text(), self._selected_avatar())
        except NetworkError as exc:
            self._show_error(str(exc))
            return
        finally:
            QApplication.restoreOverrideCursor()
            self.join_button.setEnabled(True)
            self.join_button.setText("Join Chat  →")

        if self.remember.isChecked():          # the password is never saved
            self.settings.setValue("remember", True)
            self.settings.setValue("username", username)
            self.settings.setValue("server", self.server_input.text().strip())
            self.settings.setValue("avatar", self._selected_avatar())
        else:
            self.settings.clear()
        self.accept()
