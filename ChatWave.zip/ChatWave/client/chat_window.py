"""Main chat window: conversation list (sidebar) + message thread + input bar."""
from __future__ import annotations

import html
from datetime import datetime

from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtGui import QKeyEvent
from PyQt6.QtWidgets import (
    QFrame, QHBoxLayout, QLabel, QLineEdit, QMessageBox, QPushButton, QScrollArea,
    QTextBrowser, QVBoxLayout, QWidget,
)

from client.config import APP_NAME, TIMESTAMP_FORMAT
from client.emoji_picker import EmojiPicker
from client.network import NetworkClient
from client.styles import BACKGROUND, BORDER, MUTED, ONLINE, PRIMARY, PRIMARY_SOFT, TEXT
from client.widgets import AvatarWidget, ChatTile, color_for
from common.protocol import (
    EDIT, EDITED, ERROR, MAX_MESSAGE_LENGTH, MESSAGE, PUBLIC_CHAT, SYSTEM, USERS,
)

GROUP_TITLE = "Group Chat"
GROUP_SYMBOL = "👥"


def format_timestamp(ts: float) -> str:
    return datetime.fromtimestamp(ts).strftime(TIMESTAMP_FORMAT)


def format_short_time(ts: float) -> str:
    """Time shown on the conversation list: clock today, 'Yesterday', else 'Aug 31'."""
    when, now = datetime.fromtimestamp(ts), datetime.now()
    days = (now.date() - when.date()).days
    if days == 0:
        return when.strftime("%I:%M %p").lstrip("0")
    if days == 1:
        return "Yesterday"
    return when.strftime("%b %d")


class ChatWindow(QWidget):
    def __init__(self, network: NetworkClient, session: dict) -> None:
        super().__init__()
        self.network = network
        self.username: str = session["username"]
        self.avatar: str = session["avatar"]
        self.me_key = self.username.lower()

        self.users: dict[str, dict] = {}            # lower-case username -> {username, avatar, online}
        self.conversations: dict[str, list[dict]] = {PUBLIC_CHAT: []}
        self.unread: dict[str, int] = {}
        self.tiles: dict[str, ChatTile] = {}
        self.current_key = PUBLIC_CHAT
        self.editing_id: str | None = None
        self.logged_out = False
        self.connected = True

        self.setWindowTitle(f"{APP_NAME} - {self.avatar} {self.username}")
        self.resize(940, 680)
        self.setMinimumSize(720, 520)
        self._build_ui()
        self._ensure_tile(PUBLIC_CHAT)
        self._apply_users(session["users"])
        for message in session["history"]:
            self._store_message(message)
        for key in self.conversations:
            self._refresh_tile(key)
        self._relayout_tiles()
        self._select_conversation(PUBLIC_CHAT)

        network.packet_received.connect(self._handle_packet)
        network.connection_lost.connect(self._on_connection_lost)
        network.start_listening()

    # ================================================================== UI
    def _build_ui(self) -> None:
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.setStyleSheet(f"ChatWindow {{ background: {BACKGROUND}; }}")
        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)
        root.addWidget(self._build_sidebar())
        root.addWidget(self._build_thread_panel(), 1)

    def _build_sidebar(self) -> QWidget:
        side = QFrame()
        side.setFixedWidth(300)
        side.setStyleSheet(f"QFrame#Sidebar {{ background: white; border-right: 1px solid {BORDER}; }}")
        side.setObjectName("Sidebar")
        lay = QVBoxLayout(side)
        lay.setContentsMargins(14, 14, 14, 14)
        lay.setSpacing(10)

        me = QHBoxLayout()
        me.addWidget(AvatarWidget(self.avatar, color_for(self.username), online=True, size=44))
        names = QVBoxLayout()
        names.setSpacing(0)
        brand = QLabel(self.username)
        brand.setStyleSheet(f"font-size: 15px; font-weight: 700; color: {TEXT};")
        sub = QLabel(f"● Online  ·  {APP_NAME}")
        sub.setStyleSheet(f"font-size: 11px; color: {ONLINE};")
        names.addWidget(brand)
        names.addWidget(sub)
        me.addLayout(names, 1)
        logout = QPushButton("Log out")
        logout.setObjectName("Flat")
        logout.setCursor(Qt.CursorShape.PointingHandCursor)
        logout.clicked.connect(self._logout)
        me.addWidget(logout)
        lay.addLayout(me)

        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("🔍  Search conversations...")
        self.search_input.textChanged.connect(self._filter_tiles)
        lay.addWidget(self.search_input)

        self.tile_layout = QVBoxLayout()
        self.tile_layout.setSpacing(8)
        self.tile_layout.setContentsMargins(0, 0, 0, 0)
        container = QWidget()
        container.setObjectName("TileContainer")
        container.setStyleSheet("QWidget#TileContainer { background: transparent; }")
        container.setLayout(self.tile_layout)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setStyleSheet("QScrollArea { background: transparent; }")
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setWidget(container)
        lay.addWidget(scroll, 1)
        return side

    def _build_thread_panel(self) -> QWidget:
        panel = QWidget()
        lay = QVBoxLayout(panel)
        lay.setContentsMargins(16, 14, 16, 14)
        lay.setSpacing(10)

        header = QFrame()
        header.setStyleSheet(f"QFrame {{ background: {PRIMARY}; border-radius: 12px; }} QLabel {{ background: transparent; color: white; }}")
        h = QVBoxLayout(header)
        h.setContentsMargins(16, 10, 16, 10)
        h.setSpacing(0)
        self.header_title = QLabel("")
        self.header_title.setTextFormat(Qt.TextFormat.PlainText)
        self.header_title.setStyleSheet("font-size: 18px; font-weight: 700;")
        self.header_sub = QLabel("")
        self.header_sub.setStyleSheet("font-size: 12px; color: #E8E5FF;")
        h.addWidget(self.header_title)
        h.addWidget(self.header_sub)
        lay.addWidget(header)

        self.chat_box = QTextBrowser()
        self.chat_box.setOpenLinks(False)
        self.chat_box.setStyleSheet(
            f"QTextBrowser {{ background: white; border: 1px solid {BORDER}; border-radius: 12px; padding: 8px; font-size: 14px; }}")
        lay.addWidget(self.chat_box, 1)

        self.edit_banner = QFrame()
        self.edit_banner.setStyleSheet(f"QFrame {{ background: {PRIMARY_SOFT}; border-radius: 8px; }} QLabel {{ background: transparent; color: {PRIMARY}; font-weight: 600; }}")
        eb = QHBoxLayout(self.edit_banner)
        eb.setContentsMargins(12, 6, 8, 6)
        eb.addWidget(QLabel("✏️  Editing your message - press Enter to save"))
        eb.addStretch()
        cancel = QPushButton("Cancel")
        cancel.setObjectName("Flat")
        cancel.clicked.connect(self._cancel_edit)
        eb.addWidget(cancel)
        self.edit_banner.hide()
        lay.addWidget(self.edit_banner)

        self.status_label = QLabel("")
        self.status_label.setStyleSheet("color: #DC2626; font-size: 12px;")
        self.status_label.hide()
        lay.addWidget(self.status_label)

        row = QHBoxLayout()
        self.emoji_button = QPushButton("😊")
        self.emoji_button.setObjectName("Flat")
        self.emoji_button.setFixedWidth(52)
        self.emoji_button.setStyleSheet("font-size: 18px;")
        self.emoji_button.clicked.connect(self._show_emoji_picker)
        self.message_input = QLineEdit()
        self.message_input.setPlaceholderText("Type a message...")
        self.message_input.setMaxLength(MAX_MESSAGE_LENGTH)
        self.message_input.returnPressed.connect(self._send)
        self.send_button = QPushButton("Send")
        self.send_button.setObjectName("Primary")
        self.send_button.clicked.connect(self._send)
        row.addWidget(self.emoji_button)
        row.addWidget(self.message_input, 1)
        row.addWidget(self.send_button)
        lay.addLayout(row)

        self.edit_button = QPushButton("✏️  Edit last message")
        self.edit_button.setObjectName("Flat")
        self.edit_button.clicked.connect(self._start_edit)
        lay.addWidget(self.edit_button)

        self.emoji_picker = EmojiPicker(self)
        self.emoji_picker.emoji_selected.connect(self._insert_emoji)
        return panel

    # ========================================================= conversations
    def _conversation_key(self, message: dict) -> str:
        target = message.get("to")
        if not target:
            return PUBLIC_CHAT
        return target.lower() if message["sender"].lower() == self.me_key else message["sender"].lower()

    def _ensure_tile(self, key: str) -> None:
        if key in self.tiles:
            return
        if key == PUBLIC_CHAT:
            tile = ChatTile(key, GROUP_TITLE, GROUP_SYMBOL, None)
        else:
            user = self.users[key]
            tile = ChatTile(key, user["username"], user["avatar"], user["online"])
        tile.clicked.connect(self._select_conversation)
        self.tiles[key] = tile
        self.conversations.setdefault(key, [])

    def _apply_users(self, users: list[dict]) -> None:
        for user in users:
            key = user["username"].lower()
            if key == self.me_key:
                continue
            self.users[key] = user
            self._ensure_tile(key)
            self.tiles[key].avatar.set_state(user["avatar"], user["online"])
        self._relayout_tiles()
        self._update_header()

    def _last_activity(self, key: str) -> float:
        real = [m for m in self.conversations.get(key, []) if m.get("kind") != "system"]
        return real[-1]["timestamp"] if real else 0.0

    def _relayout_tiles(self) -> None:
        """Group chat pinned on top; then by recent activity, online users first, then name."""
        while self.tile_layout.count():
            self.tile_layout.takeAt(0)
        others = sorted((k for k in self.tiles if k != PUBLIC_CHAT),
                        key=lambda k: (-self._last_activity(k),
                                       not self.users[k]["online"], self.users[k]["username"].lower()))
        for key in [PUBLIC_CHAT, *others]:
            self.tile_layout.addWidget(self.tiles[key])
        self.tile_layout.addStretch()
        self._filter_tiles(self.search_input.text())

    def _filter_tiles(self, text: str) -> None:
        needle = text.strip().lower()
        for tile in self.tiles.values():
            tile.setVisible(needle in tile.title.lower())

    def _store_message(self, message: dict) -> str:
        key = self._conversation_key(message)
        if key != PUBLIC_CHAT and key not in self.users and key != self.me_key:
            self.users[key] = {"username": message["sender"], "avatar": message["avatar"], "online": False}
        if key != self.me_key:
            self._ensure_tile(key)
        self.conversations.setdefault(key, []).append(message)
        return key

    def _refresh_tile(self, key: str) -> None:
        tile = self.tiles.get(key)
        if tile is None:
            return
        real = [m for m in self.conversations.get(key, []) if m.get("kind") != "system"]
        if real:
            last = real[-1]
            mine = last["sender"].lower() == self.me_key
            prefix = "You: " if mine else (f"{last['sender']}: " if key == PUBLIC_CHAT else "")
            tile.set_preview(prefix + last["text"], format_short_time(last["timestamp"]))
        tile.set_unread(self.unread.get(key, 0))

    def _select_conversation(self, key: str) -> None:
        self._cancel_edit()
        self.current_key = key
        self.unread[key] = 0
        for k, tile in self.tiles.items():
            tile.set_selected(k == key)
        self._refresh_tile(key)
        self._update_header()
        self._render()
        self.message_input.setFocus()

    def _update_header(self) -> None:
        if self.current_key == PUBLIC_CHAT:
            online = 1 + sum(1 for u in self.users.values() if u["online"])
            self.header_title.setText(f"{GROUP_SYMBOL}  {GROUP_TITLE}")
            self.header_sub.setText(f"{online} online · messages go to everyone")
        else:
            user = self.users[self.current_key]
            self.header_title.setText(f"{user['avatar']}  {user['username']}")
            self.header_sub.setText("● Online - private chat" if user["online"]
                                    else "Offline - they will see your messages when they log in")

    # ============================================================= rendering
    def _render(self) -> None:
        parts = []
        for m in self.conversations.get(self.current_key, []):
            if m.get("kind") == "system":
                parts.append(f'<p align="center" style="color:{MUTED}; font-size:12px; margin:6px;">'
                             f'{html.escape(m["text"])}</p>')
                continue
            mine = m["sender"].lower() == self.me_key
            bg = "#EDEBFF" if mine else "#FFFFFF"
            edited = f' <i style="color:{MUTED}; font-size:11px;">(edited)</i>' if m.get("edited") else ""
            parts.append(
                f'<table width="100%" cellspacing="0" cellpadding="7" style="margin-bottom:4px;"><tr>'
                f'<td width="34" bgcolor="{bg}" style="font-size:22px;">{html.escape(m["avatar"])}</td>'
                f'<td bgcolor="{bg}"><b style="color:{PRIMARY};">{html.escape(m["sender"])}</b> '
                f'<span style="color:{MUTED}; font-size:11px;">[{format_timestamp(m["timestamp"])}]</span>{edited}'
                f'<br>{html.escape(m["text"])}</td></tr></table>')
        self.chat_box.setHtml("".join(parts))
        bar = self.chat_box.verticalScrollBar()
        bar.setValue(bar.maximum())

    # ================================================================ sending
    def _send(self) -> None:
        text = self.message_input.text().strip()
        if not text or not self.connected:
            return
        if self.editing_id:
            ok = self.network.send({"type": EDIT, "id": self.editing_id, "text": text})
            self._cancel_edit()
        else:
            target = None if self.current_key == PUBLIC_CHAT else self.users[self.current_key]["username"]
            ok = self.network.send({"type": MESSAGE, "text": text, "to": target})
        if ok:
            self.message_input.clear()
        else:
            self._flash_status("Message could not be sent.")

    def _insert_emoji(self, emoji: str) -> None:
        self.message_input.insert(emoji)
        self.message_input.setFocus()

    def _show_emoji_picker(self) -> None:
        self.emoji_picker.show_above(self.emoji_button)

    # ================================================================ editing
    def _start_edit(self) -> None:
        mine = [m for m in self.conversations.get(self.current_key, [])
                if m.get("kind") != "system" and m["sender"].lower() == self.me_key]
        if not mine:
            QMessageBox.information(self, "Edit message", "You have no message to edit in this chat yet.")
            return
        self.editing_id = mine[-1]["id"]
        self.message_input.setText(mine[-1]["text"])
        self.edit_banner.show()
        self.message_input.setFocus()

    def _cancel_edit(self) -> None:
        if self.editing_id:
            self.message_input.clear()
        self.editing_id = None
        self.edit_banner.hide()

    def keyPressEvent(self, event: QKeyEvent) -> None:
        if event.key() == Qt.Key.Key_Escape and self.editing_id:
            self._cancel_edit()
        else:
            super().keyPressEvent(event)

    # ============================================================== incoming
    def _handle_packet(self, packet: dict) -> None:
        kind = packet.get("type")
        if kind == MESSAGE:
            self._on_message(packet["message"])
        elif kind == EDITED:
            self._on_edited(packet)
        elif kind == USERS:
            self._apply_users(packet["users"])
        elif kind == SYSTEM:
            self.conversations[PUBLIC_CHAT].append({"kind": "system", "text": packet["text"],
                                                    "timestamp": packet["timestamp"]})
            if self.current_key == PUBLIC_CHAT:
                self._render()
        elif kind == ERROR:
            self._flash_status(packet.get("reason", "Something went wrong."))

    def _on_message(self, message: dict) -> None:
        key = self._store_message(message)
        if key != self.current_key and message["sender"].lower() != self.me_key:
            self.unread[key] = self.unread.get(key, 0) + 1
        self._refresh_tile(key)
        self._relayout_tiles()
        if key == self.current_key:
            self._render()

    def _on_edited(self, packet: dict) -> None:
        for key, messages in self.conversations.items():
            for m in messages:
                if m.get("id") == packet["id"]:
                    m["text"], m["edited"] = packet["text"], True
                    self._refresh_tile(key)
                    if key == self.current_key:
                        self._render()
                    return

    def _flash_status(self, text: str) -> None:
        self.status_label.setText(text)
        self.status_label.show()
        QTimer.singleShot(4000, self.status_label.hide)

    # ============================================================ connection
    def _on_connection_lost(self) -> None:
        if not self.connected:
            return
        self.connected = False
        for widget in (self.message_input, self.send_button, self.emoji_button, self.edit_button):
            widget.setEnabled(False)
        self.header_sub.setText("Disconnected from server")
        QMessageBox.warning(self, "Connection lost",
                            "The connection to the server was lost.\nClose this window and log in again.")

    def _logout(self) -> None:
        self.logged_out = True
        self.close()

    def closeEvent(self, event) -> None:
        self.network.close()
        super().closeEvent(event)
