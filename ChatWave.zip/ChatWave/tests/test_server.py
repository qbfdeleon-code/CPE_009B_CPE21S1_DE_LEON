"""Integration tests: start a real server on a random port and talk to it with raw sockets.

Run from the project root:  python -m unittest discover -s tests -v
"""
import socket
import tempfile
import threading
import unittest

from common.protocol import (
    EDIT, EDITED, ERROR, LOGIN, LOGIN_ERROR, LOGIN_OK, MESSAGE, SYSTEM, USERS,
    PacketReader, encode_packet,
)
from server.chat_server import ChatServer


class TestClient:
    """Tiny blocking client used only by the tests."""

    def __init__(self, port):
        self.sock = socket.create_connection(("127.0.0.1", port), timeout=3)
        self.reader = PacketReader()
        self.queue = []

    def send(self, **packet):
        self.sock.sendall(encode_packet(packet))

    def recv(self, kind=None):
        """Return the next packet (optionally the next one of a given type)."""
        while True:
            while self.queue:
                packet = self.queue.pop(0)
                if kind is None or packet["type"] == kind:
                    return packet
            data = self.sock.recv(4096)
            if not data:
                raise ConnectionError("closed")
            self.queue.extend(self.reader.feed(data))

    def login(self, username, password="", avatar="😎"):
        self.send(type=LOGIN, username=username, password=password, avatar=avatar)
        return self.recv()

    def close(self):
        self.sock.close()


class ServerTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.server = ChatServer("127.0.0.1", 0, self.tmp.name)
        threading.Thread(target=self.server.serve_forever, daemon=True).start()
        self.assertTrue(self.server.ready.wait(3))
        self.clients = []

    def tearDown(self):
        for c in self.clients:
            c.close()
        self.server.shutdown()
        self.tmp.cleanup()

    def connect(self):
        c = TestClient(self.server.port)
        self.clients.append(c)
        return c

    def test_login_ok_and_user_list(self):
        reply = self.connect().login("Hail")
        self.assertEqual(reply["type"], LOGIN_OK)
        self.assertEqual(reply["username"], "Hail")
        self.assertTrue(any(u["username"] == "Hail" and u["online"] for u in reply["users"]))

    def test_invalid_username_rejected(self):
        self.assertEqual(self.connect().login("x")["type"], LOGIN_ERROR)
        self.assertEqual(self.connect().login("bad name!")["type"], LOGIN_ERROR)

    def test_duplicate_login_rejected(self):
        self.connect().login("Hail")
        self.assertEqual(self.connect().login("hail")["type"], LOGIN_ERROR)

    def test_password_is_enforced_once_set(self):
        first = self.connect()
        first.login("Maria", "secret")
        first.close()
        self.assertEqual(self.connect().login("Maria", "wrong")["type"], LOGIN_ERROR)
        self.assertEqual(self.connect().login("Maria", "secret")["type"], LOGIN_OK)

    def test_group_message_reaches_everyone(self):
        a, b = self.connect(), self.connect()
        a.login("Alice")
        b.login("Bob")
        a.send(type=MESSAGE, text="Hello!", to=None)
        for client in (a, b):
            msg = client.recv(MESSAGE)["message"]
            self.assertEqual((msg["sender"], msg["text"], msg["to"]), ("Alice", "Hello!", None))

    def test_private_message_is_private(self):
        a, b, c = self.connect(), self.connect(), self.connect()
        a.login("Alice"); b.login("Bob"); c.login("Cara")
        a.send(type=MESSAGE, text="psst", to="Bob")
        self.assertEqual(a.recv(MESSAGE)["message"]["text"], "psst")
        self.assertEqual(b.recv(MESSAGE)["message"]["text"], "psst")
        c.send(type=MESSAGE, text="ping", to=None)
        # Cara's next MESSAGE must be her own group message, never the private one
        self.assertEqual(c.recv(MESSAGE)["message"]["text"], "ping")

    def test_edit_only_own_messages(self):
        a, b = self.connect(), self.connect()
        a.login("Alice"); b.login("Bob")
        a.send(type=MESSAGE, text="typo", to=None)
        msg_id = a.recv(MESSAGE)["message"]["id"]
        b.send(type=EDIT, id=msg_id, text="hacked")
        self.assertEqual(b.recv(ERROR)["type"], ERROR)
        a.send(type=EDIT, id=msg_id, text="fixed")
        edited = b.recv(EDITED)
        self.assertEqual((edited["id"], edited["text"]), (msg_id, "fixed"))

    def test_empty_and_unknown_target_rejected(self):
        a = self.connect()
        a.login("Alice")
        a.send(type=MESSAGE, text="   ", to=None)
        self.assertEqual(a.recv(ERROR)["type"], ERROR)
        a.send(type=MESSAGE, text="hi", to="Nobody")
        self.assertEqual(a.recv(ERROR)["type"], ERROR)

    def test_messages_glued_in_one_tcp_chunk_are_split(self):
        a = self.connect()
        a.login("Alice")
        a.sock.sendall(encode_packet({"type": MESSAGE, "text": "one", "to": None})
                       + encode_packet({"type": MESSAGE, "text": "two", "to": None}))
        self.assertEqual(a.recv(MESSAGE)["message"]["text"], "one")
        self.assertEqual(a.recv(MESSAGE)["message"]["text"], "two")

    def test_history_and_offline_dm_delivered_on_next_login(self):
        a = self.connect()
        a.login("Alice")
        a.send(type=MESSAGE, text="for later", to="Alice")  # self-DM keeps the test simple
        a.recv(MESSAGE)
        a.send(type=MESSAGE, text="group hello", to=None)
        a.recv(MESSAGE)
        a.close()
        reply = self.connect().login("Alice")
        texts = [m["text"] for m in reply["history"]]
        self.assertEqual(texts, ["for later", "group hello"])

    def test_join_and_leave_notifications(self):
        a, b = self.connect(), self.connect()
        a.login("Alice")
        b.login("Bob")
        self.assertIn("Bob joined", a.recv(SYSTEM)["text"] + a.recv(SYSTEM)["text"])
        b.close()
        presence = a.recv(USERS)
        while any(u["username"] == "Bob" and u["online"] for u in presence["users"]):
            presence = a.recv(USERS)
        self.assertFalse(any(u["online"] for u in presence["users"] if u["username"] == "Bob"))


if __name__ == "__main__":
    unittest.main()
