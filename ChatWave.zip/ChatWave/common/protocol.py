"""Wire protocol shared by the ChatWave server and client.

Every packet is one JSON object terminated by a newline ("\\n"), sent over TCP.
Framing with newlines fixes a classic socket bug: TCP is a byte *stream*, so two
messages sent quickly can arrive glued together in one ``recv()`` call.
``PacketReader`` buffers incoming bytes and only returns complete packets.

Client -> Server
    login    {type, username, password, avatar}
    message  {type, text, to}          to = None (group chat) or a username (private)
    edit     {type, id, text}

Server -> Client
    login_ok     {type, username, avatar, users, history}
    login_error  {type, reason}
    message      {type, message}       message = {id, sender, avatar, text, timestamp, to, edited}
    edited       {type, id, text}
    users        {type, users}         users = [{username, avatar, online}]
    system       {type, text, timestamp}
    error        {type, reason}
"""
from __future__ import annotations

import json
import re

DEFAULT_HOST = "127.0.0.1"
DEFAULT_PORT = 5555
ENCODING = "utf-8"

MAX_PACKET_BYTES = 64 * 1024
MAX_MESSAGE_LENGTH = 1000
PUBLIC_CHAT = "public"  # key of the group conversation

USERNAME_PATTERN = re.compile(r"^[A-Za-z0-9_.-]{2,20}$")
USERNAME_RULES = "Username must be 2-20 characters: letters, numbers, _ . -"

AVATARS = ["👤", "😀", "😎", "😂", "🥰", "😈", "🤖", "🐱", "🐶", "🐼"]

# Packet types
LOGIN = "login"
LOGIN_OK = "login_ok"
LOGIN_ERROR = "login_error"
MESSAGE = "message"
EDIT = "edit"
EDITED = "edited"
USERS = "users"
SYSTEM = "system"
ERROR = "error"


class ProtocolError(Exception):
    """Raised when received data is not a valid packet."""


def encode_packet(packet: dict) -> bytes:
    """Serialise a packet to newline-terminated UTF-8 JSON."""
    return (json.dumps(packet, ensure_ascii=False) + "\n").encode(ENCODING)


class PacketReader:
    """Accumulates raw bytes and yields complete packets."""

    def __init__(self) -> None:
        self._buffer = bytearray()

    def feed(self, data: bytes) -> list[dict]:
        self._buffer.extend(data)
        packets: list[dict] = []
        while True:
            end = self._buffer.find(b"\n")
            if end == -1:
                break
            line = bytes(self._buffer[:end])
            del self._buffer[: end + 1]
            if not line.strip():
                continue
            try:
                packet = json.loads(line.decode(ENCODING))
            except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                raise ProtocolError("Malformed packet") from exc
            if not isinstance(packet, dict) or "type" not in packet:
                raise ProtocolError("Packet must be an object with a 'type'")
            packets.append(packet)
        if len(self._buffer) > MAX_PACKET_BYTES:
            raise ProtocolError("Packet too large")
        return packets
